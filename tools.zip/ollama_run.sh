#!/usr/bin/env bash
L=/tmp/logs; mkdir -p $L
(curl -fsSL https://ollama.com/install.sh | sh) > $L/ollama_install.txt 2>&1
(ollama serve > $L/ollama_serve.txt 2>&1 &)
sleep 5
ollama pull llama3.1:8b > $L/ollama_pull.txt 2>&1
cd /tmp/bundle/w3p/assignments/03-anatomy-of-coding-agents/prompting-techniques/work
for f in k_shot_prompting chain_of_thought tool_calling rag; do
  echo "### $f" ; (time python $f.py) 2>&1
done > $L/w3p.txt
echo DONE > $L/ollama_status.txt
