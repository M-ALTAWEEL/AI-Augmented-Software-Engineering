"""Drive server.py through a real MCP client session over STDIO and print a transcript."""
import asyncio, json, sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

CALLS = [
    ("search_countries", {"query": "guinea", "limit": 5}),
    ("get_country_details", {"name": "Jordan"}),
    ("get_country_details", {"name": "Niger"}),
    ("get_country_details", {"name": "12345"}),
    ("get_country_details", {"name": "Atlantis"}),
    ("search_countries", {"query": "   "}),
    ("search_countries", {"query": "jor", "limit": 99}),
]

async def main(server_path):
    params = StdioServerParameters(command=sys.executable, args=[server_path])
    async with stdio_client(params) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            tools = await s.list_tools()
            print("## tools/list")
            for t in tools.tools:
                print(f"- {t.name}: params={list(t.inputSchema.get('properties', {}))}")
            for name, args in CALLS:
                res = await s.call_tool(name, args)
                text = "\n".join(c.text for c in res.content if getattr(c, "text", None))
                try:
                    text = json.dumps(json.loads(text), ensure_ascii=False, indent=2)
                except Exception:
                    pass
                print(f"\n## tools/call {name} {json.dumps(args, ensure_ascii=False)}\n```json\n{text}\n```")

asyncio.run(main(sys.argv[1]))
