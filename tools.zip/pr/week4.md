Week 4 — Structuring a Repo for Agents (`04-agentic-codebase-structure/work/`).

- `AGENTS.md` (43 lines), scoped test rules (`tests/AGENTS.md` + glob rule `.agents/rules/tests.md`), and a reusable `implement-feature` skill (`.agents/skills/implement-feature/SKILL.md`).
- Feature: **Task 2 — Click counter** (`GET /stats/{code}`), including a migration for existing `links.db` files.
- `pytest -q` → **10 passed** (3 original + 7 new). The review stage returned **ACCEPT** (log in `work/agent_log.md`).
- Writeup: [work/writeup.md](https://github.com/M-ALTAWEEL/AI-Augmented-Software-Engineering/blob/week4-M-ALTAWEEL/assignments/04-agentic-codebase-structure/work/writeup.md)
