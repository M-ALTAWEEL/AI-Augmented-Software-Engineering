Week 5 — Data Explorer MCP server (`05-advanced-context-management/work/`).

- Second tool `get_country_details(name)` returns currencies, languages, borders and flag URL. Both tools return structured errors and never crash (`invalid_input`, `not_found`, `timeout`, `network`, `auth`, `rate_limited`, `upstream_http`, `bad_response`).
- **Note:** REST Countries v3.1 has been retired (every URL returns a deprecation error). The server uses v5 when `RESTCOUNTRIES_API_KEY` is set, and otherwise the open `mledoze/countries` dataset, with the same output shape. `mcp` is pinned `<2` because 2.x removed `FastMCP`.
- `pytest -q` → **38 passed**. The server was driven from an MCP client (GitHub Copilot agent mode); the transcript is in `work/agent_transcript.md`.
- Writeup: [work/writeup.md](https://github.com/M-ALTAWEEL/AI-Augmented-Software-Engineering/blob/week5-M-ALTAWEEL/assignments/05-advanced-context-management/work/writeup.md), tool reference: [work/README.md](https://github.com/M-ALTAWEEL/AI-Augmented-Software-Engineering/blob/week5-M-ALTAWEEL/assignments/05-advanced-context-management/work/README.md)
