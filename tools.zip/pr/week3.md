Week 3 — Prompting Techniques submission (`prompting-techniques/work/`).

- All four checks pass on `llama3.1:8b` (Ollama, temperature 0): **k-shot 4/4, CoT 3/3, tool calling PASS, RAG 3/3**.
- For comparison, every technique was also re-run with an empty prompt (`baseline.txt`): k-shot 0/4, CoT 0/3, tool calling PASS, RAG 2/3.
- Writeup: [`work/writeup.md`](https://github.com/M-ALTAWEEL/AI-Augmented-Software-Engineering/blob/week3-prompting-M-ALTAWEEL/assignments/03-anatomy-of-coding-agents/prompting-techniques/work/writeup.md)
