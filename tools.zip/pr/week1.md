**Week 1 — course-materials improvement.** This adds a heads-up box to the Week 5 (MCP server) assignment for two problems that currently break the starter on a fresh setup:

1. **REST Countries v3.1 has been retired.** Every `restcountries.com/v3.1/...` URL now returns `301` → *"This API version has been deprecated … migrate to our new version (v5)"*, so `search_countries` returns an error for every query. v5 (`api.restcountries.com/countries/v5`) answers `401 authKeyMissing` without a free key. The note explains this, shows the v5 field changes, and points to a no-key alternative (the `mledoze/countries` dataset).
2. **`mcp` 2.x removed `mcp.server.fastmcp`.** The unpinned `requirements.txt` installs mcp 2.3.0, and `from mcp.server.fastmcp import FastMCP` raises `ModuleNotFoundError`. The note shows how to pin `mcp>=1.2,<2`.

Both were reproduced in a clean environment (Python 3.14, Oct 23 2026). I also added a tip about testing the STDIO server with MCP Inspector.
