#!/usr/bin/env bash
# Builds one branch per week from /tmp/bundle, runs tests, collects logs in /tmp/logs.
set -u
cd /workspaces/AI-Augmented-Software-Engineering
git config user.name "Mouhammed Altaweel"
git config user.email "252200590+M-ALTAWEEL@users.noreply.github.com"
B=/tmp/bundle; L=/tmp/logs; mkdir -p $L
git checkout -q main

# Week 1
git checkout -q -B improve-week5-mcp-pin main
git apply $B/w1/week5-mcp-pin.patch && git add assignments && git commit -q -m "Week 5: note that mcp 2.x breaks the FastMCP starter

- Add a Common mistake note: mcp 2.x renamed FastMCP to MCPServer
- Show how to pin mcp<2 and verify the import
- Tip: server.py waits silently on STDIO; try it with MCP Inspector"
# verify the claim on a clean venv
python -m venv /tmp/v2 && /tmp/v2/bin/pip -q install mcp httpx >/dev/null 2>&1
{ echo "== latest mcp:"; /tmp/v2/bin/pip show mcp | grep Version; /tmp/v2/bin/python -c "from mcp.server.fastmcp import FastMCP" 2>&1 | tail -1; } > $L/w1.txt

# Week 4
git checkout -q -B week4-M-ALTAWEEL main
cp -r $B/w4/. .
W=assignments/04-agentic-codebase-structure/work
(cd $W && python -m pytest -q 2>&1 | tail -15) > $L/w4.txt
rm -f $W/links.db; rm -rf $W/.pytest_cache $W/__pycache__ $W/tests/__pycache__
git add $W && git commit -q -m "Week 4: agent-ready link shortener with click counter"

# Week 5
git checkout -q -B week5-M-ALTAWEEL main
cp -r $B/w5/. .
W=assignments/05-advanced-context-management/work
(cd $W && python -m pytest -q 2>&1 | tail -15) > $L/w5.txt
python /tmp/tools/mcp_demo_client.py $W/server.py > $L/w5_transcript.md 2>&1
rm -rf $W/.pytest_cache $W/__pycache__
git add $W && git commit -q -m "Week 5: Data Explorer MCP server with get_country_details"

# Week 3 prompting (results filled in later after Ollama runs)
git checkout -q -B week3-prompting-M-ALTAWEEL main
cp -r $B/w3p/. .
git add assignments/03-anatomy-of-coding-agents/prompting-techniques/work && git commit -q -m "Week 3: prompting techniques (k-shot, CoT, tool calling, RAG)"

git checkout -q main
git log --oneline --all -8 > $L/git.txt
echo DONE > $L/status.txt
