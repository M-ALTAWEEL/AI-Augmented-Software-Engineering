#!/usr/bin/env bash
# Re-run each technique with an EMPTY prompt (and empty tool descriptions) for comparison.
L=/tmp/logs
cd ${B:-/tmp/bundle}/w3p/assignments/03-anatomy-of-coding-agents/prompting-techniques/work
{
echo "### k_shot (empty prompt)";  python -c "import k_shot_prompting as m; m.YOUR_SYSTEM_PROMPT=''; m.run()"
echo "### chain_of_thought (empty prompt)"; python -c "import chain_of_thought as m; m.YOUR_SYSTEM_PROMPT=''; m.run()"
echo "### tool_calling (empty prompt + empty descriptions)"; python -c "
import tool_calling as m
m.YOUR_SYSTEM_PROMPT=''
f=m.TOOLS[0]['function']; f['description']=''; f['parameters']['properties']['order_id']['description']=''
m.run()"
echo "### rag (empty prompt, retriever kept)"; python -c "import rag as m; m.YOUR_SYSTEM_PROMPT=''; m.run()"
echo "### rag (prompt kept, retriever returns ALL chunks)"; python -c "import rag as m; m.YOUR_RETRIEVER=lambda q,c: c; m.run()"
} > $L/w3p_baseline.txt 2>&1
echo DONE > $L/baseline_status.txt
