#!/usr/bin/env bash
# Publish /tmp/logs to the scratch branch so they can be read back.
set -e
cd /tmp && rm -rf logsrepo && git clone -q -b upload-bundle https://github.com/M-ALTAWEEL/AI-Augmented-Software-Engineering logsrepo 2>/dev/null || git -C /workspaces/AI-Augmented-Software-Engineering worktree add -f /tmp/logsrepo upload-bundle
cd /tmp/logsrepo && mkdir -p logs && cp /tmp/logs/* logs/ && git add logs && git -c user.name="Mouhammed Altaweel" -c user.email="252200590+M-ALTAWEEL@users.noreply.github.com" commit -q -m logs && git push -q origin HEAD:upload-bundle && echo PUSHED
