#!/usr/bin/env bash
# Rebuild branches from the final bundle, verify, push, and open PRs.
set -u
cd /workspaces/AI-Augmented-Software-Engineering
git checkout -q -f main
B=${B:-/tmp/bundle3} bash /tmp/tools/run_all.sh
L=/tmp/logs
for br in improve-week5-mcp-pin week3-prompting-M-ALTAWEEL week4-M-ALTAWEEL week5-M-ALTAWEEL; do
  echo "== $br: $(git diff --stat main..$br | tail -1)"
  git push -q -f origin $br 2>&1 | tail -2
done > $L/push.txt 2>&1
U=scottyUX/AI-Augmented-Software-Engineering
P=/tmp/tools/pr
{
gh pr create --repo $U --base main --head M-ALTAWEEL:improve-week5-mcp-pin --title "Week 5: warn that REST Countries v3.1 is retired and mcp 2.x breaks the starter" --body-file $P/week1.md
gh pr create --repo $U --base main --head M-ALTAWEEL:week3-prompting-M-ALTAWEEL --title "Week 3 Prompting Techniques: Mouhammed Altaweel" --body-file $P/week3.md
gh pr create --repo $U --base main --head M-ALTAWEEL:week4-M-ALTAWEEL --title "Week 4: Mouhammed Altaweel" --body-file $P/week4.md
gh pr create --repo $U --base main --head M-ALTAWEEL:week5-M-ALTAWEEL --title "Week 5: Mouhammed Altaweel" --body-file $P/week5.md
} > $L/prs.txt 2>&1
cat $L/push.txt $L/prs.txt
