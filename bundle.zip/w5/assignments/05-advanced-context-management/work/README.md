# Data Explorer — MCP Server

An MCP server (STDIO transport) that wraps the free, no-key
[REST Countries](https://restcountries.com) API and exposes it to an agent as two tools.

## Install

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

> `mcp` is pinned to `<2`: version 2.x renamed `FastMCP` to `MCPServer`, so the
> 1.x import `from mcp.server.fastmcp import FastMCP` fails on a fresh unpinned install.

## Run

```bash
python server.py        # speaks MCP over STDIO; it waits silently for a client
pytest -q               # offline tests (API is faked), no network needed
```

Try it interactively with the MCP Inspector (needs Node.js):

```bash
npx @modelcontextprotocol/inspector python server.py
```

## Register in an MCP client

Use **absolute paths**, and point `command` at the Python inside your venv so the
client finds `mcp` and `httpx`.

**Antigravity** — Agent panel → `…` → *MCP Servers* → *Manage MCP Servers* → *View raw config*
(`mcp_config.json`):

```json
{
  "mcpServers": {
    "data-explorer": {
      "command": "/absolute/path/to/starter/.venv/bin/python",
      "args": ["/absolute/path/to/starter/server.py"]
    }
  }
}
```

**Claude Desktop** — Settings → Developer → Edit Config (`claude_desktop_config.json`), same
`mcpServers` block. **VS Code** uses `.vscode/mcp.json` with a top-level `"servers"` key
instead of `"mcpServers"`.

On Windows the Python path looks like `C:\\path\\to\\starter\\.venv\\Scripts\\python.exe`.

## Tool reference

### `search_countries(query: str, limit: int = 5) -> list[dict]`

Find countries by full or partial name.

| Parameter | Type | Rules |
|---|---|---|
| `query` | string | 1–100 chars; letters, spaces and `. ' - ( ) , &` only |
| `limit` | int | 1–25, default 5 |

```jsonc
// input
{"query": "jor", "limit": 2}
// output
[{"name": "Jordan", "capital": "Amman", "region": "Asia", "population": 11302255}]
// no match -> []
```

### `get_country_details(name: str) -> dict`

Details for one country. Tries an exact full-name match first (so `Niger` doesn't
return `Nigeria`), then falls back to a partial match and picks the closest name.

| Parameter | Type | Rules |
|---|---|---|
| `name` | string | same rules as `query` |

```jsonc
// input
{"name": "Jordan"}
// output
{
  "name": "Jordan",
  "official_name": "Hashemite Kingdom of Jordan",
  "capital": "Amman",
  "region": "Asia",
  "currencies": [{"code": "JOD", "name": "Jordanian dinar", "symbol": "د.ا"}],
  "languages": ["Arabic"],
  "borders": ["IRQ", "ISR", "PSE", "SAU", "SYR"],
  "flag_url": "https://flagcdn.com/w320/jo.png",
  "flag_emoji": "🇯🇴"
}
```

When a partial name matches several countries, the result also has
`"other_matches": [...]` (up to 5 names).

### Errors (both tools)

Tools never raise. Failures come back as
`{"error": "<human-readable message>", "error_type": "<kind>"}`
(`search_countries` wraps it in a one-item list).

| `error_type` | When |
|---|---|
| `invalid_input` | empty, too long, wrong type, or illegal characters; `limit` out of range |
| `not_found` | `get_country_details` found no country |
| `timeout` | API didn't answer within 10 s |
| `network` | DNS / connection failure |
| `upstream_http` | API returned 4xx/5xx other than 404 (e.g. 429, 500) |
| `bad_response` | API returned non-JSON or an unexpected shape |
