# Week 5 — Data Explorer MCP Server: Writeup

## Client and setup
- MCP client: **Google Antigravity** (`mcp_config.json`, see README)
- Transport: STDIO, command `<venv>/bin/python /abs/path/server.py`
- `mcp` pinned to `<2` — mcp 2.x removed `mcp.server.fastmcp`, so the unpinned starter
  fails to import on a fresh install.

## Transcript — agent calling both tools

> Paste the real chat from your client (prompt → tool call + arguments → tool result →
> agent reply). Screenshots are fine as extra evidence.

**Prompt 1:** `Use the data-explorer tools: which countries match "guinea"?`
```
<!-- PASTE tool call: search_countries {"query": "guinea", ...} and result -->
```

**Prompt 2:** `Get the currencies, languages, neighbors and flag of Jordan.`
```
<!-- PASTE tool call: get_country_details {"name": "Jordan"} and result -->
```

**Prompt 3 (bad input):** `Call get_country_details with the name "12345".`
```
<!-- PASTE: expected {"error": "name may only contain letters, ...", "error_type": "invalid_input"} -->
```

**Prompt 4 (no result):** `Get details for the country "Atlantis".`
```
<!-- PASTE: expected {"error": "no country found matching 'Atlantis'; ...", "error_type": "not_found"} -->
```

## How I handled errors

Both tools **never raise**. Every failure becomes `{"error": <message>, "error_type": <kind>}`,
so the agent can read what went wrong and decide what to do next (retry, fix the input, or
call `search_countries` first). One shared helper, `_get_json`, owns all HTTP handling:

| Failure | Handling |
|---|---|
| Empty / whitespace / wrong type / >100 chars / digits or symbols | `invalid_input`, rejected **before** any network call |
| `limit` outside 1–25 (or a bool/string) | `invalid_input` |
| Special characters (`Côte d'Ivoire`) | allowed and URL-encoded with `quote()`, so `/` or `?` can't change the API path |
| 404 from the API | `search_countries` → `[]`; `get_country_details` → `not_found` with a hint to use search |
| Timeout (10 s) | `timeout` |
| DNS / connection error | `network` |
| 429 / 5xx | `upstream_http` with the status code |
| Non-JSON / unexpected shape | `bad_response` |
| Missing fields (e.g. Antarctica has no currency) | empty lists / `null`, no `KeyError` |

`get_country_details` first asks for an exact full-name match (`fullText=true`) so
`"Niger"` doesn't return Nigeria, then falls back to a partial match and adds
`other_matches` so the agent knows the answer was ambiguous. The response asks the API only
for the fields it needs (`fields=...`), which keeps the payload — and the agent's context — small.

`test_server.py` (31 cases, API faked with `monkeypatch`) checks all of the above offline:
`pytest -q` → `<!-- PASTE result -->`.

## What I learned

An MCP server is a context boundary: the agent can only reach what the tools expose, in the
shape the tools return it. Choosing a small, fixed return shape (and asking the API for
only those fields) keeps the context window clean instead of dumping a large raw JSON
blob into it. Structured errors matter as much as success results, because the error text
is what the model reasons over next — "not found, try `search_countries`" steers the agent
better than a stack trace. Validating input before the network call is also a safety
control: the model can't use the tool to hit arbitrary URLs or paths.
