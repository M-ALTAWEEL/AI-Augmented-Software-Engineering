"""Data Explorer — an MCP server over the free, no-key REST Countries API.

Exposes two tools to an agent over STDIO:

* ``search_countries(query, limit)``  – find countries by (partial) name.
* ``get_country_details(name)``       – currencies, languages, borders and flag for one country.

Both tools never raise: every failure (bad input, HTTP error, timeout, bad JSON,
no results) comes back as a small structured value the model can read and act on.

Setup:
    pip install -r requirements.txt
Run (STDIO) — register this command in your MCP client:
    python server.py
"""
from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote

import httpx
from mcp.server.fastmcp import FastMCP

BASE_URL = "https://restcountries.com/v3.1"
TIMEOUT_SECONDS = 10.0
MAX_NAME_LENGTH = 100
MAX_LIMIT = 25

# Letters (any script), spaces, and the punctuation that appears in real country
# names: "Côte d'Ivoire", "Guinea-Bissau", "St. Lucia", "Congo (Kinshasa)".
_VALID_NAME = re.compile(r"^[^\W\d_]+(?:[\s'’.\-(),&][^\W\d_]*)*\.?\)?$", re.UNICODE)

mcp = FastMCP("data-explorer")


# --------------------------------------------------------------------------- helpers
def _error(message: str, kind: str) -> dict[str, str]:
    """Uniform error shape: the model always sees ``{"error": ..., "error_type": ...}``."""
    return {"error": message, "error_type": kind}


def _validate_name(value: Any, field: str) -> tuple[str | None, dict | None]:
    """Return (clean_value, None) or (None, error_dict)."""
    if not isinstance(value, str):
        return None, _error(f"{field} must be a string", "invalid_input")
    cleaned = " ".join(value.split())  # trim + collapse internal whitespace
    if not cleaned:
        return None, _error(f"{field} must not be empty", "invalid_input")
    if len(cleaned) > MAX_NAME_LENGTH:
        return None, _error(
            f"{field} is too long (max {MAX_NAME_LENGTH} characters)", "invalid_input"
        )
    if not _VALID_NAME.match(cleaned):
        return None, _error(
            f"{field} may only contain letters, spaces and . ' - ( ) , &", "invalid_input"
        )
    return cleaned, None


def _get_json(path: str, params: dict | None = None) -> tuple[Any, dict | None]:
    """GET ``BASE_URL + path``.

    Returns ``(data, None)`` on success, ``(None, None)`` when the API says
    "not found" (404), and ``(None, error_dict)`` for every other failure.
    """
    try:
        resp = httpx.get(f"{BASE_URL}{path}", params=params, timeout=TIMEOUT_SECONDS)
    except httpx.TimeoutException:
        return None, _error(
            f"REST Countries did not respond within {TIMEOUT_SECONDS:g}s; try again later",
            "timeout",
        )
    except httpx.RequestError as exc:
        return None, _error(f"could not reach REST Countries: {exc.__class__.__name__}", "network")

    if resp.status_code == 404:
        return None, None
    if resp.status_code >= 400:
        return None, _error(
            f"REST Countries returned HTTP {resp.status_code}", "upstream_http"
        )
    try:
        data = resp.json()
    except ValueError:
        return None, _error("REST Countries returned a response that is not JSON", "bad_response")
    if not isinstance(data, list):
        return None, _error("REST Countries returned an unexpected response shape", "bad_response")
    return data, None


# --------------------------------------------------------------------------- tools
@mcp.tool()
def search_countries(query: str, limit: int = 5) -> list[dict]:
    """Search countries by (partial) name.

    Returns up to ``limit`` items shaped ``{name, capital, region, population}``.
    An empty list means no country matched. On failure returns a one-item list
    ``[{"error": ..., "error_type": ...}]``.
    """
    clean, err = _validate_name(query, "query")
    if err:
        return [err]
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_LIMIT:
        return [_error(f"limit must be an integer between 1 and {MAX_LIMIT}", "invalid_input")]

    data, err = _get_json(
        f"/name/{quote(clean, safe='')}",
        params={"fields": "name,capital,region,population"},
    )
    if err:
        return [err]
    if not data:
        return []  # no matches is not an error

    return [
        {
            "name": (c.get("name") or {}).get("common"),
            "capital": (c.get("capital") or [None])[0],
            "region": c.get("region"),
            "population": c.get("population"),
        }
        for c in data[:limit]
    ]


@mcp.tool()
def get_country_details(name: str) -> dict:
    """Get details for ONE country by its common or official name (e.g. "Jordan").

    Returns ``{name, official_name, capital, region, currencies, languages,
    borders, flag_url, flag_emoji}`` where ``currencies`` is a list of
    ``{code, name, symbol}``, ``languages`` a list of names and ``borders`` a list
    of ISO 3166-1 alpha-3 codes (empty for island nations).
    On failure or no match returns ``{"error": ..., "error_type": ...}``.
    Use ``search_countries`` first if you are unsure of the exact name.
    """
    clean, err = _validate_name(name, "name")
    if err:
        return err

    fields = {"fields": "name,capital,region,currencies,languages,borders,flags,flag"}
    path = f"/name/{quote(clean, safe='')}"

    # 1) exact full-name match first, so "Niger" does not return "Nigeria".
    data, err = _get_json(path, params={**fields, "fullText": "true"})
    if err:
        return err
    # 2) fall back to a partial match ("Korea" -> several hits).
    if not data:
        data, err = _get_json(path, params=fields)
        if err:
            return err
    if not data:
        return _error(
            f"no country found matching '{clean}'; try search_countries to find the exact name",
            "not_found",
        )

    country = _pick_best_match(data, clean)
    result = _shape_details(country)
    if len(data) > 1:
        others = [(c.get("name") or {}).get("common") for c in data if c is not country]
        result["other_matches"] = [n for n in others if n][:5]
    return result


# --------------------------------------------------------------------------- shaping
def _pick_best_match(countries: list[dict], wanted: str) -> dict:
    """Prefer an exact (case-insensitive) common/official name match, else the first hit."""
    w = wanted.casefold()
    for c in countries:
        names = c.get("name") or {}
        if w in {str(names.get("common", "")).casefold(), str(names.get("official", "")).casefold()}:
            return c
    return countries[0]


def _shape_details(c: dict) -> dict:
    names = c.get("name") or {}
    currencies = [
        {"code": code, "name": (info or {}).get("name"), "symbol": (info or {}).get("symbol")}
        for code, info in sorted((c.get("currencies") or {}).items())
    ]
    languages = sorted((c.get("languages") or {}).values())
    flags = c.get("flags") or {}
    return {
        "name": names.get("common"),
        "official_name": names.get("official"),
        "capital": (c.get("capital") or [None])[0],
        "region": c.get("region"),
        "currencies": currencies,
        "languages": languages,
        "borders": list(c.get("borders") or []),
        "flag_url": flags.get("png") or flags.get("svg"),
        "flag_emoji": c.get("flag"),
    }


if __name__ == "__main__":
    mcp.run()  # STDIO transport by default
