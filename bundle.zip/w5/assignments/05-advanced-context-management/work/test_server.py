"""Offline tests for server.py — the REST Countries API is faked with monkeypatch.

Run:  pytest -q
"""
import httpx
import pytest

import server

JORDAN = {
    "name": {"common": "Jordan", "official": "Hashemite Kingdom of Jordan"},
    "capital": ["Amman"],
    "region": "Asia",
    "population": 11_000_000,
    "currencies": {"JOD": {"name": "Jordanian dinar", "symbol": "د.ا"}},
    "languages": {"ara": "Arabic"},
    "borders": ["IRQ", "ISR", "PSE", "SAU", "SYR"],
    "flags": {"png": "https://flagcdn.com/w320/jo.png", "svg": "https://flagcdn.com/jo.svg"},
    "flag": "🇯🇴",
}
NIGER = {"name": {"common": "Niger", "official": "Republic of Niger"}, "capital": ["Niamey"]}
NIGERIA = {"name": {"common": "Nigeria", "official": "Federal Republic of Nigeria"}}


def fake_get(responses):
    """Return a fake httpx.get that replays ``responses`` (Response objects or exceptions)."""
    calls = []
    queue = list(responses)

    def _get(url, params=None, timeout=None):
        calls.append({"url": url, "params": params})
        item = queue.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    _get.calls = calls
    return _get


def resp(status, json=None, text=None):
    req = httpx.Request("GET", "https://restcountries.com/v3.1/x")
    if json is not None:
        return httpx.Response(status, json=json, request=req)
    return httpx.Response(status, text=text or "", request=req)


# ----------------------------------------------------------------- search_countries
def test_search_success(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(200, [JORDAN])]))
    out = server.search_countries("jordan")
    assert out == [{"name": "Jordan", "capital": "Amman", "region": "Asia", "population": 11_000_000}]


def test_search_respects_limit(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(200, [JORDAN, NIGER, NIGERIA])]))
    assert len(server.search_countries("n", limit=2)) == 2


def test_search_no_results_is_empty_list(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(404, {"status": 404})]))
    assert server.search_countries("atlantis") == []


@pytest.mark.parametrize("bad", ["", "   ", "123", "drop table;", "x" * 101, None])
def test_search_rejects_bad_query(bad):
    out = server.search_countries(bad)
    assert out[0]["error_type"] == "invalid_input"


@pytest.mark.parametrize("bad_limit", [0, -1, 26, "5", True])
def test_search_rejects_bad_limit(bad_limit):
    assert server.search_countries("jordan", limit=bad_limit)[0]["error_type"] == "invalid_input"


def test_search_timeout(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([httpx.ReadTimeout("slow")]))
    assert server.search_countries("jordan")[0]["error_type"] == "timeout"


def test_search_http_500(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(500, text="boom")]))
    assert server.search_countries("jordan")[0]["error_type"] == "upstream_http"


def test_search_url_encodes_query(monkeypatch):
    get = fake_get([resp(200, [])])
    monkeypatch.setattr(server.httpx, "get", get)
    server.search_countries("Côte d'Ivoire")
    assert "C%C3%B4te%20d%27Ivoire" in get.calls[0]["url"]


# ------------------------------------------------------------- get_country_details
def test_details_success_shape(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(200, [JORDAN])]))
    out = server.get_country_details("Jordan")
    assert out == {
        "name": "Jordan",
        "official_name": "Hashemite Kingdom of Jordan",
        "capital": "Amman",
        "region": "Asia",
        "currencies": [{"code": "JOD", "name": "Jordanian dinar", "symbol": "د.ا"}],
        "languages": ["Arabic"],
        "borders": ["IRQ", "ISR", "PSE", "SAU", "SYR"],
        "flag_url": "https://flagcdn.com/w320/jo.png",
        "flag_emoji": "🇯🇴",
    }


def test_details_tries_full_text_first(monkeypatch):
    get = fake_get([resp(200, [NIGER])])
    monkeypatch.setattr(server.httpx, "get", get)
    assert server.get_country_details("niger")["name"] == "Niger"
    assert get.calls[0]["params"]["fullText"] == "true"


def test_details_falls_back_to_partial_and_picks_exact(monkeypatch):
    get = fake_get([resp(404, {}), resp(200, [NIGERIA, NIGER])])
    monkeypatch.setattr(server.httpx, "get", get)
    out = server.get_country_details("Niger")
    assert out["name"] == "Niger"
    assert out["other_matches"] == ["Nigeria"]
    assert "fullText" not in get.calls[1]["params"]


def test_details_missing_fields_do_not_crash(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(200, [{"name": {"common": "Antarctica"}}])]))
    out = server.get_country_details("Antarctica")
    assert out["currencies"] == [] and out["languages"] == [] and out["borders"] == []
    assert out["capital"] is None and out["flag_url"] is None


def test_details_not_found(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(404, {}), resp(404, {})]))
    assert server.get_country_details("Atlantis")["error_type"] == "not_found"


@pytest.mark.parametrize("bad", ["", "  ", "42", "<script>", None])
def test_details_rejects_bad_name(bad):
    assert server.get_country_details(bad)["error_type"] == "invalid_input"


def test_details_network_error(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([httpx.ConnectError("dns")]))
    assert server.get_country_details("Jordan")["error_type"] == "network"


def test_details_timeout(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([httpx.ConnectTimeout("slow")]))
    assert server.get_country_details("Jordan")["error_type"] == "timeout"


def test_details_bad_json(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(200, text="<html>")]))
    assert server.get_country_details("Jordan")["error_type"] == "bad_response"


def test_details_http_429(monkeypatch):
    monkeypatch.setattr(server.httpx, "get", fake_get([resp(429, text="slow down")]))
    out = server.get_country_details("Jordan")
    assert out["error_type"] == "upstream_http" and "429" in out["error"]
