# Week 3 — Prompting Techniques: Writeup

Model: `llama3.1:8b` via Ollama, `temperature=0.0`.

> Fill the `<!-- PASTE -->` blocks with the real output from your own runs.
> The "What I learned" lines describe the usual behavior of an empty vs. finished prompt —
> run the empty prompt once yourself, check that it matches, and rewrite in your own words.

## 1. K-shot prompting — ticket classification

**Final prompt:** (see `YOUR_SYSTEM_PROMPT` in `k_shot_prompting.py`) — a label list with a
one-line definition per label, a strict "label only, lowercase" output rule, and 9 labeled
examples (at least two per class) written as `Message:` / `Label:` pairs.

**Sample:**
```
<!-- PASTE: python k_shot_prompting.py -->
```

**What I learned:** With zero examples the model answered in sentences ("This is a billing
issue."), which fails exact-match grading. The examples fixed the output **format** more
than the classification itself.

## 2. Chain-of-thought — refund eligibility

**Final prompt:** forces one line per policy rule in a fixed order (days → condition →
final sale), each marked PASS/FAIL, an explicit "any FAIL means NO" rule, a default for
missing information ("not mentioned = unused / not final sale"), one worked example, and
an exact last line `DECISION: YES|NO`.

**Sample:**
```
<!-- PASTE: python chain_of_thought.py -->
```

**What I learned:** Step-by-step reasoning helped most on the "45 days, unused" case, where
the model has to notice a single failing rule among passing ones. The defaults for missing
info stopped it from answering NO because "condition is unknown".

## 3. Tool calling — order lookup

**Final prompt + schema:** the tool description says *when* to call it ("whenever the user
asks about an order and gives an order number") and forbids guessing; the `order_id`
description pins the format (digits only, no `#`, example `"4412"`). The system prompt says
the assistant cannot see order data itself and MUST call the tool first.

**Sample:**
```
<!-- PASTE: python tool_calling.py -->
```

**What I learned:** With empty descriptions the model sometimes answered from imagination
instead of calling the tool. The tool description is itself a prompt: it decides whether
the model calls the tool and what argument format it sends.

## 4. RAG — grounded answers

**Retriever:** keyword overlap. Lowercase, tokenize, drop stopwords, map question words to
the help center's vocabulary (`ship → shipping`, `internationally → international`,
`refund → returns`), crude singularization, score each line by shared tokens, keep the top 3
with score > 0. The CEO question retrieves **nothing**, so the model gets an empty context.

**Final prompt:** answer only from the context, reuse the context's wording for key facts,
and reply with a fixed refusal sentence ("I don't know…") when the context doesn't contain
the answer.

**Sample:**
```
<!-- PASTE: python rag.py -->
```

**What I learned:** The refusal case is decided mostly by the **retriever**: returning
nothing for an off-topic question makes refusing easy. Retrieving irrelevant lines
"just in case" invites the model to stitch together an answer.

## Closing — why LLMs are good at structured tasks, and where they need scaffolding

LLMs are strong at structured tasks because they have seen huge amounts of text that
already follows patterns — labels, step lists, JSON, Q&A — so a few examples or a clear
schema is enough for them to copy the pattern. They need scaffolding in three places:
**output format** (exact labels and final lines must be specified, or they add chatty
text), **multi-condition logic** (they skip rules unless told to check each one), and
**facts they don't have** (order status, store policy), which must come from a tool or
retrieved context together with an explicit rule not to guess. In short, the model brings
the language skill; the prompt, tools and retriever supply the structure and the truth.
