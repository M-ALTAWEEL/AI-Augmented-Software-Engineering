# Week 4 — Structuring a Repo for Agents: Writeup

**Agent:** Google Antigravity · **Feature:** Task 2, Click counter (`GET /stats/{code}`)

## 1. What's in `AGENTS.md`, and why it's broadly available
A one-paragraph product summary, a file map, install/run/test commands, product boundaries
(no auth, UI, ORM or new dependencies), a few conventions (parameterized SQL, migration-safe
schema changes, status-code meanings) and the four-step change workflow. Every task needs
this regardless of which file it touches: where things are, how to verify, and what not to
build. It stays under 60 lines so it doesn't crowd out task context.

## 2. The scoped instruction and when it loads
`tests/AGENTS.md` holds the testing rules: test only through the public HTTP API, cover
success and failure, keep each test independent with a fresh temp database (the `client`
fixture in `tests/conftest.py`), and assert on behavior rather than storage. It is
activated by `.agents/rules/tests.md`, an Antigravity rule with `trigger: glob` and
`globs: tests/**`, so it only loads when the agent reads or edits a file under `tests/`.
These rules are noise when the agent is editing docs or reading routes, so loading them
for every task would waste context and dilute the always-on guidance.

## 3. The reusable workflow
`.agents/skills/implement-feature/SKILL.md` encodes test-first feature work: read the task
and guidance → inspect code/tests and confirm green → state behavior, edge cases, files and
migration plan → write failing tests and confirm they fail for the right reason → smallest
implementation → `pytest -q` → summarize changes, results and risks.

## 4. How Antigravity discovers each artifact
| Artifact | Discovery |
|---|---|
| `AGENTS.md` (root) | Read automatically as workspace context |
| `tests/AGENTS.md` | Pulled in by the glob rule in `.agents/rules/` when a `tests/**` file is in play |
| `implement-feature` skill | Workspace skill in `.agents/skills/`; the agent sees its `description` and loads the body when a prompt matches (or when named: "use the implement-feature skill") |

## 5. What planning/review caught
<!-- Edit to match what YOUR agent said. Typical findings for this task: -->
- **Planning:** an existing `links.db` would lack the new `clicks` column, so
  `CREATE TABLE IF NOT EXISTS` alone isn't enough → guarded `ALTER TABLE` migration plus a
  test that upgrades an old-schema database.
- **Planning:** the original tests share one real `links.db`, so new tests use a
  per-test temp database fixture to stay independent.
- **Review:** the increment uses `clicks = clicks + 1` in SQL (atomic) rather than
  read-then-write in Python, so concurrent visits aren't lost; viewing `/stats` must not
  count as a click (test added). Verdict: `ACCEPT` <!-- or REVISE → what you fixed -->

Tests: `pytest -q` → <!-- PASTE e.g. "10 passed" -->

## 6. What I learned
An agent starts every session as a new teammate with no memory, so the repository has to
explain itself. Splitting guidance by when it is needed — always-on orientation, path-scoped
rules, and on-demand procedures — keeps the context small and relevant. Writing the
workflow down made the agent's behavior repeatable: it planned, wrote failing tests first,
and stayed inside the product boundaries instead of over-building. Separate plan, implement
and review stages caught issues (schema migration, test isolation) that a single "just build
it" prompt would likely have missed.
